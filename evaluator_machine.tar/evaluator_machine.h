#ifndef EVALUATOR_MACHINE
#define EVALUATOR_MACHINE

#include <stdio.h>
#include <unistd.h>
#include "ex00/ft_ft.c"
#include "ex01/ft_ultimate_ft.c"
#include "ex02/ft_swap.c"
#include "ex03/ft_div_mod.c"

void menu_exercise(int *);
void main_ex00(void);
void main_ex01(void);
void main_ex02(void);
//void main_ex03(void);
//void main_ex04(void);
//void main_ex05(void);
//void main_ex06(void);
//void main_ex07(void);
//void main_ex08(void);
//void main_ex09(void);
//void main_ex10(void);
//void main_ex11(void);
//void ft_ultimate_ft(int *********);



#endif

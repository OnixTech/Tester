#ifndef EVALUATOR_MACHINE
#define EVALUATOR_MACHINE

#include <stdio.h>
#include <unistd.h>
//#include "main_exxx_c01.h"
#include "main_exxx_c02.h"

void menu_exercise(int *);
void end(int *);


#endif

#include "main_exxx_c02.h"

void main_ex00(void)
{
	printf("Exercise 00:\n");
	printf("Reproduce the behavior of the function strcpy (man strcpy).\n");
}

void main_ex01(void)
{
		printf("Exercise 01:\n");
		printf("Create a function that returns 1 if the string given as a parameter contains only alphabetical characters, and 0 if it contains any other character.\n");

}

void  main_ex02(void)
{
		printf("Exercise 02:\n");
		printf("Create a function that swaps the value of two integers whose addresses are entered as parameters.\n");
}
void main_ex03(void)
{
		printf("Exercise 03:\n");
		printf("Create a function that returns 1 if the string given as a parameter contains only digits, and 0 if it contains any other character.\n");

}
void main_ex04(void)
{
		printf("Exercise 04:\n");
		printf("Create a function that returns 1 if the string given as a parameter contains only lowercase alphabetical characters, and 0 if it contains any other character.\n");
}
void main_ex05(void)
{
		printf("Exercise 05:\n");
		printf("Create a function that returns 1 if the string given as a parameter contains only uppercase alphabetical characters, and 0 if it contains any other character.\n");

}
void main_ex06(void)
{
		printf("Exercise 06:\n");
		printf("Create a function that returns 1 if the string given as a parameter contains only printable characters, and 0 if it contains any other character.\n");


}
void main_ex07(void)
{
		printf("Exercise 07:\n");
		printf("Create a function that transforms every letter to uppercase.\n");

}
void main_ex08(void)
{
		printf("Exercise 08:\n");
		printf("Create a function that transforms every letter to lowercase.\n");

}

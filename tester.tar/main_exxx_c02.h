#ifndef MAIN_EXXX_C02
#define MAIN_EXXX_C02


#include <stdio.h>
#include <unistd.h>

// #include "ex00/ft_strcpy.c"
// #include "ex01/ft_strncpy.c"
// #include "ex02/ft_str_is_alpha.c"
// #include "ex03/ft_str_is_numeric.c"
// #include "ex04/ft_str_is_lowercase.c"
// #include "ex05/ft_str_is_uppercase.c"
// #include "ex06/ft_str_is_printable.c"
// #include "ex07/ft_strupcase.c"
// #include "ex08/ft_strlowcase.c"


void main_ex00(void);
void main_ex01(void);
void main_ex02(void);
void main_ex03(void);
void main_ex04(void);
void main_ex05(void);
void main_ex06(void);
void main_ex07(void);
void main_ex08(void);
//void main_ex09(void);
//void main_ex10(void);
//void main_ex11(void);

#endif
